# Calc_processing

This package is used to print mult table and sum all elements in array.


## Installation

Use the package manager [pip](https://pip.pypa.io/eng/stable) to install this package

`pip install calc_processing`

## Usage

**Mult Table:**

```python
from mult_table.table import mult_10
```

**Sum elements in array**:

```python
from arr_sum.result import sum_all
```

